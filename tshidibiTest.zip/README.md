** Je vais rediger ce fichier comme si j'étais allé au bout de la conception du travail qui m'a été demandé, chose que je ne saurais faire suite au hardware défaillant en ma possession.

La version finie de l'application devait fonctionner comme suit :
- Au lancement de l'application, l'utilisateur arrive sur la page d'accueil sur laquelle s'affiche sous forme d'un tableau la liste de tous les candidats sous forme d'un tableau à une colonne ne contenant aue les noms des candidats contenus dans le fichier "api.json".
- Lors d'un click sur l'un des noms affichés, l'utilisateur est rédirigé vers la page "lecteur.Js" qui affiche le nom du candidat correspondant, sa vidéo et la question à laquelle il a repondu.
  Au bas de la vidéo, est intégré une balise "textarea" qui permet aux utilisateurs de commenter la réponse entendu sur la vidéo. Une fois que l'utilisateur valide son commentaitre en cliquant sur le bouton "enregistrer" sous la balise "textarea", l'application enregistrer
  dans le fichier "api.Json", comme valeur de la sous-clé "comments" contenu dans la sous-clé "vidéos" de la clé "applications".
  
  Dans le cadre de ma solution, j'ai opté pour une solution flexible en utilisant le langage descriptif HTML, une feuille de style en CSS et du React pour le coté frontend et NodeJs pour le backend.
  Avec un meilleur hardware, donc une optimisation du temps aui m'a été imparti, je pense que j'aurais pu mener ce projet à terme.
  
  Vous trouverez le code source du projet en suivant ce lien: https://github.com/Oli-Kabeya/243test.io.git
  
  Je vous remercie de l'opportunité qui m'a été offert, tout en espérant faire de l'équipe dans les prochains jours.