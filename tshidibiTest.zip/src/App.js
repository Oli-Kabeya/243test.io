import logo from './logo.svg';
import './App.css';
import api from './api.json';
function App() {
  return (
				<div class="liste">
					<h1>Liste des candidates</h1>
                    <table border="2">
                        <tbody>
                            <tr>
                                <th>Noms</th>
                            </tr>
                            {api.candidates.map((item, i) => (
                                <tr key={i}>
                                    <td id="reponse">{item.name}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
  );
			}

export default App;
